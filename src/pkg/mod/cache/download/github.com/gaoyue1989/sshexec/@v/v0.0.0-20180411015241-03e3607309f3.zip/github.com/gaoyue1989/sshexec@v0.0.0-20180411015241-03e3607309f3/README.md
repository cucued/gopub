# sshexec - Go library for executing SSH commands and sftp send file

This is a simple Go library for starting an SSH client agent and use sftp send file  by grpool

Example usage can be found in the *example* directory.
