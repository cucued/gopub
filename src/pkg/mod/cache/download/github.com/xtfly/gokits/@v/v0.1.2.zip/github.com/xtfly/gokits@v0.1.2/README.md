Some golang tool kits
===========

golang tool kits, some are collected from internet.

This package need >= **go 1.12**