# Goroutine local storage

Experimental Goroutine local storage using GoRoutine address as the ID library for golang.

This package is heavily inspired by [tylerb' gls](https://github.com/tylerb/gls) package.
