# Goroutine local storage

Experimental Goroutine local storage using GoRoutine address as the ID library for golang.

